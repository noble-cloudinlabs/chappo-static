=== Ulina ===
Contributors: Ulan
Requires at least: WordPress 5.0.x
Tested up to: WordPress 5.0
Version: 1.0
License: 
License URI:
Tags: one-column, two-columns, right-sidebar, flexible-header, accessibility-ready, custom-colors, custom-header, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, post-formats, rtl-language-support, sticky-post, theme-options, threaded-comments, translation-ready

